SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=false
REPLACE="
"
print_modname() {
  ui_print "*******************************"
  ui_print "*       Riru - EdXposed       *"
  ui_print "*******************************"
}
on_install() {
  ui_print "- Extracting module files"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'system_x86/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'data/*' -d $MODPATH >&2
  
  # check_architecture
  if [[ "$ARCH" != "arm" && "$ARCH" != "arm64" && "$ARCH" != "x86" && "$ARCH" != "x64" ]]; then
    ui_print "- Unsupported platform: $ARCH"
    exit 1
  else
    ui_print "- Device platform: $ARCH"
  fi
  
  # copy_files
  cp -af $INSTALLER/common/util_functions.sh $MODPATH/util_functions.sh
  if [[ "$ARCH" == "x86" || "$ARCH" == "x64" ]]; then
	ui_print "- Removing arm/arm64 libraries"
    rm -rf "$MODPATH/system/lib"
    rm -rf "$MODPATH/system/lib64"
    # ui_print "- Extracting x86/64 libraries"
	# unzip -o "$ZIP" 'system_x86/*' -d $MODPATH
    mv "$MODPATH/system_x86/lib" "$MODPATH/system/lib"
    mv "$MODPATH/system_x86/lib64" "$MODPATH/system/lib64"
  else
    ui_print "- Removing x86/x64 libraries"
    rm -rf "$MODPATH/system_x86/lib"
    rm -rf "$MODPATH/system_x86/lib64"
  fi

  if [[ "$IS64BIT" = false ]]; then
	  ui_print "- Removing 64-bit libraries"
	  rm -rf "$MODPATH/system/lib64"
  fi

  # ui_print "- Extracting extra files"
  # unzip -o "$ZIP" 'data/*' -d "$MODPATH"
  
  ls $MODPATH
  
  ui_print "MODPATH: $MODPATH"
  
  TARGET="/data/misc/riru/modules"
  
  # TODO: do not overwrite if file exists
  [[ -d "$TARGET" ]] || mkdir -p "$TARGET" || fail "- Can't mkdir -p $TARGET"
  cp -af "$MODPATH$TARGET/." "$TARGET" || fail "- Can't cp -af $MODPATH$TARGET/. $TARGET"

  rm -rf "$MODPATH/data"
  
  ui_print "- Files copied"
}
set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0644
}
fail() {
  echo "$1"
  exit 1
}
